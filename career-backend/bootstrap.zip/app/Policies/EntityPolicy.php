<?php

namespace App\Policies;

use App\Models\User;
use App\Policies\Concerns\ChecksPermission;

class EntityPolicy
{
    use ChecksPermission;

    public function viewAny(User $user): bool
    {
        return $this->allows($user, 'content.manage');
    }

    public function view(User $user): bool
    {
        return $this->viewAny($user);
    }

    /** Adding, renaming, hiding and deleting companies is for Admin (entities.manage). */
    public function create(User $user): bool
    {
        return $this->allows($user, 'entities.manage');
    }

    public function update(User $user): bool
    {
        return $this->allows($user, 'content.manage');
    }

    public function delete(User $user): bool
    {
        return $this->allows($user, 'entities.manage');
    }

    public function manage(User $user): bool
    {
        return $this->allows($user, 'entities.manage');
    }
}
