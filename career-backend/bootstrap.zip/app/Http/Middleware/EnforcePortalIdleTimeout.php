<?php

namespace App\Http\Middleware;

use App\Support\GuardSignOut;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnforcePortalIdleTimeout
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth('web')->check()) {
            $last = session('hr.last_activity');

            if (is_string($last) && now()->diffInMinutes($last, true) >= 30) {
                GuardSignOut::end('web');

                return response()->json([
                    'message' => 'Your session expired. Sign in again.',
                    'code' => 'session_expired',
                ], 401);
            }

            // Background polling (the notification bell) must not keep an idle session alive.
            if (! $request->headers->has('X-Background-Request')) {
                session(['hr.last_activity' => now()->toIso8601String()]);
            }
        }

        return $next($request);
    }
}
